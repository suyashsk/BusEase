package com.bookmybus.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookmybus.entity.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer>{

}
