package com.bookmybus.bean;

import java.util.List;

import com.bookmybus.entity.Passenger;



public class ListPassenger {
	List<Passenger> pass1;

	public List<Passenger> getPass1() {
		return pass1;
	}

	public void setPass1(List<Passenger> pass1) {
		this.pass1 = pass1;
	}

	
}
